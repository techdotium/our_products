import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AnimatedSplashScreen(
          splash: Text(
            "INIFINITY",
            style: TextStyle(fontSize: 55),
          ),
          nextScreen: home_page()),
    );
  }
}

class home_page extends StatefulWidget {
  const home_page({Key? key}) : super(key: key);

  @override
  _home_pageState createState() => _home_pageState();
}

class _home_pageState extends State<home_page> {
  int index = 0;
  final page = [
    main_page(),
    contact(),
    about(),
    account(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: page[index],
        bottomNavigationBar: Container(
          child: BottomNavigationBar(
            currentIndex: index,
            type: BottomNavigationBarType.fixed,
            items: [
              BottomNavigationBarItem(
                icon: Icon(
                  FontAwesomeIcons.houseDamage,
                  color: Colors.black,
                ),
                title: Text(""),
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  FontAwesomeIcons.addressBook,
                  color: Colors.black,
                ),
                title: Text(""),
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  FontAwesomeIcons.infoCircle,
                  color: Colors.black,
                ),
                title: Text(""),
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  FontAwesomeIcons.userAlt,
                  color: Colors.black,
                ),
                title: Text(""),
              ),
            ],
            onTap: (currentIndex) {
              setState(() {
                index = currentIndex;
              });
            },
          ),
        ));
  }
}

@override
Widget build(BuildContext context) {
  return const Scaffold(
    body: SafeArea(
      child: WebView(
        initialUrl: 'https://gaana.com/',
        javascriptMode: JavascriptMode.unrestricted,
      ),
    ),
  );
}

class main_page extends StatefulWidget {
  const main_page({Key? key}) : super(key: key);

  @override
  _main_pageState createState() => _main_pageState();
}

class _main_pageState extends State<main_page> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: WebView(
          initialUrl: 'http://3.22.187.116/',
          javascriptMode: JavascriptMode.unrestricted,
        ),
      ),
    );
  }
}

class contact extends StatefulWidget {
  const contact({Key? key}) : super(key: key);

  @override
  _contactState createState() => _contactState();
}

class _contactState extends State<contact> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: WebView(
          initialUrl: 'http://3.22.187.116/contact/',
          javascriptMode: JavascriptMode.unrestricted,
        ),
      ),
    );
  }
}

class about extends StatefulWidget {
  const about({Key? key}) : super(key: key);

  @override
  _aboutState createState() => _aboutState();
}

class _aboutState extends State<about> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: WebView(
          initialUrl: 'http://3.22.187.116/about/',
          javascriptMode: JavascriptMode.unrestricted,
        ),
      ),
    );
  }
}

class account extends StatefulWidget {
  const account({Key? key}) : super(key: key);

  @override
  _accountState createState() => _accountState();
}

class _accountState extends State<account> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: WebView(
          initialUrl: 'http://3.22.187.116/account/',
          javascriptMode: JavascriptMode.unrestricted,
        ),
      ),
    );
  }
}
